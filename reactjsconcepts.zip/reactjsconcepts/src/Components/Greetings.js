import React from 'react'

export const Greetings = () => {
  return (
    <div>Greetings</div>
  )
}

export default Greetings;
