import React from 'react'

export const GreetingForTheDay = ({name}) => {
  return (
    <div>hi, {name} good evening</div>
  )
}

export default GreetingForTheDay;
