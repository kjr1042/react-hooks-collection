let firstName = 'abhishek';
let lastName = 'sharma';
//console.log(firstName+lastName);

let age= 22;

let birthdate = new Date();

//console.log(birthdate);

let person ={
    firstN: 'siva',
    lastN:'Kumar'
}
//console.log(person);

const customer ={
    firstName:'sudipta',
    lastName:'Roy'
}

//console.log(customer);

const customer2 ={
    firstName:'sudipta2',
    lastName:'Roy2'
}

customer2.firstName='Annam';
customer2.lastName='Ansari';

//console.log(customer2);

let squareOfNumber = function(value)
{
    return value *value;
}
//console.log(squareOfNumber(5));

for(let i=0;i<=10;i++)
{
   // console.log(i);
}
//console.log(i);

for(var i=1;i<=5;i++)
{
    console.log(i);
}
console.log('value of i:',i);

