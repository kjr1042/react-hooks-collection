class Employee{

    constructor(empId,empName,empDesign,empDept)
    {
        this.empId = empId;
        this.empName=empName;
        this.empDesign= empDesign;
        this.empDept = empDept;
    }
    showDetails()
    {
        console.log(`The Employees details ${this.empId} ${this.empName} ${this.empDesign} ${this.empDept}`);
    }
}

const employee  = new Employee(123,'raghu','manager','IT');

console.log(JSON.stringify(employee));

const employee2 =JSON.parse(JSON.stringify(employee));
console.log(employee2)
console.log(typeof employee);
console.log(JSON.stringify(employee));

//e.showDetails();